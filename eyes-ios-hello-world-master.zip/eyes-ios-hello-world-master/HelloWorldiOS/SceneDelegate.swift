// Licensed under the Applitools SDK License, which can be found here: https://www.applitools.com/eula/sdk

import UIKit

class SceneDelegate: UIResponder, UIWindowSceneDelegate {

    var window: UIWindow?

}

